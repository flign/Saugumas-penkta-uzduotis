﻿using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace SAUGUMAS_trecias
{
    public class Server
    {
        private readonly TcpListener _server;
        private NetworkStream _stream;
        private SerializedData _data = null;

        public Server(string ip, int port)
        {
            IPAddress localAddr = IPAddress.Parse(ip);
            _server = new TcpListener(localAddr, port);
        }

        public void Start()
        {
            try
            {
                // Start listening for client requests.
                _server.Start();

                // Buffer for reading data
                byte[] bytes = new byte[2048];
                _data = null;

                // Enter the listening loop.
                while (true)
                {
                    Console.Write("Laukiama aplikacijos 2... ");

                    TcpClient client = _server.AcceptTcpClient();
                    Console.WriteLine("Prisijungta");

                    _data = null;

                    _stream = client.GetStream();

                    int i;

                    // Loop to receive all the data sent by the client.
                    while ((i = _stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        _data = Serializer.Deserialize(bytes);

                        Console.WriteLine("Gauta is aplikacijos 2:");
                        Console.WriteLine("Duomenys: " + Encoding.UTF8.GetString(_data.OriginalData));
                        Console.WriteLine("Parasas: " + Convert.ToBase64String(_data.SignedData));

                        bool verified = RsaSignature.VerifySignedHash(_data.OriginalData, _data.SignedData, _data.Key);

                        if (verified == true)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Patvirtinta");
                        }
                        else
                        {
                            Console.WriteLine();
                            Console.WriteLine("Nepatvirtinta");
                        }
                    }

                    // Shutdown, end connection
                    client.Close();
                }
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }
            finally
            {
                _server.Stop();
            }
        }

        public static object ByteArrayToObject(byte[] arrBytes)
        {
            using (var memStream = new MemoryStream())
            {
                var binForm = new BinaryFormatter();
                //binForm.Binder = new PreMergeToMergedDeserializationBinder();

                memStream.Write(arrBytes, 0, arrBytes.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = binForm.Deserialize(memStream);
                return obj;
            }
        }
    }
}
