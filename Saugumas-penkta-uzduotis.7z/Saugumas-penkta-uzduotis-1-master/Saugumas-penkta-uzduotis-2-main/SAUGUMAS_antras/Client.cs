﻿using System.Net.Sockets;
using System.Text;

namespace SAUGUMAS_antras
{
    public class Client
    {
        private readonly TcpClient _client;
        private readonly NetworkStream _stream;

        public Client(string server, int port)
        {
            try
            {
                _client = new TcpClient(server, port);
                _stream = _client.GetStream();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in {nameof(Client)}: " + ex.Message);
            }
        }

        public void WaitForResponse()
        {
            try
            {
                // Receive the TcpServer.response.
                byte[] data = new byte[256];
                SerializedData responseData = null;
                int bytes = _stream.Read(data, 0, data.Length);
                responseData = Serializer.Deserialize(data);

                Console.WriteLine("Gauta is aplikacijos 2:");
                Console.WriteLine("Duomenys: " + Encoding.UTF8.GetString(responseData.OriginalData));
                Console.WriteLine("Parasas: " + Convert.ToBase64String(responseData.SignedData));

                bool verified = RsaSignature.VerifySignedHash(responseData.OriginalData, responseData.SignedData, responseData.Key);

                if (verified)
                {
                    Console.WriteLine(verified);
                }
                else
                {
                    Console.WriteLine(verified);
                }

                Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in {nameof(WaitForResponse)}: " + ex.Message);
            }

            Console.WriteLine("\n Spauskite Enter, kad iseiti...");
            Console.Read();
        }

        public void SendData(byte[] data)
        {
            try
            {
                // Send the message to the connected TcpServer.
                _stream.Write(data, 0, data.Length);

                Console.WriteLine("Informacija nusiusta i aplikacija 3");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in {nameof(SendData)}: " + ex.Message);
            }
        }

        private void Close()
        {
            // Close everything.
            _stream.Close();
            _client.Close();
        }
    }
}
